﻿namespace App.Main
{
    public enum Processing
    {
        Original,
        BW,
        Gray,
        Color,
    }
}