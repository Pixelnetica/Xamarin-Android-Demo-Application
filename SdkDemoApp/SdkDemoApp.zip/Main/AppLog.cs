﻿namespace App.Main
{
    static class AppLog
    {
        public const string TAG = "CropDemo";
    }
}